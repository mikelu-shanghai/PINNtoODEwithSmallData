import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.signal import find_peaks
import seaborn as sns

palette = sns.color_palette("muted")

def oscillator_model(t):
    def vdp(y, t, k1=15, k2=5):
        dxdt = [y[1] , k1*k2*(1-(y[0]**2))*y[1] - k1*k1*y[0]]
        return dxdt
    
    y0 = [1, 0]
    return odeint(vdp, y0, t)


def insert_points(t_data, num_inserts=3):
    new_t_data = []
    for i in range(len(t_data) - 1):
        new_t_data.append(t_data[i][0])
        inserts = np.linspace(t_data[i], t_data[i + 1], num_inserts + 2)[1:-1]
        new_t_data.extend(inserts.ravel())
    new_t_data.append(t_data[-1][0])
    return np.around(np.array(new_t_data), decimals=2)[:, None]


t = np.arange(0, 1.5, 0.01)[:, None]
y = oscillator_model(np.ravel(t))

peaks, _ = find_peaks(y[:, 0])
troughs, _ = find_peaks(-y[:, 0])

y = y[:, 0][:, None]

# t_data = np.concatenate((np.linspace(0.0, 1.5, 32)[:, None], t[peaks], t[troughs]), axis=0)
t_data = np.linspace(0.0, 1.5, 50)[:, None]
# t_data = insert_points(t_data)
# t_data = np.sort(t_data, axis=0)

y_data = np.interp(t_data.ravel(), t.ravel(), y.ravel())[:, None]

mean = 0            # 噪声均值
stddev = 0.0       # 噪声标准差
noise = np.random.normal(mean, stddev, y_data.shape)
y_data_noise = y_data + noise

plt.figure(figsize=(7, 4))
plt.plot(t, y, label="Exact solution")
plt.scatter(t_data, y_data, color="tab:orange", label="Training data")
# plt.scatter(t_data, y_data_noise.ravel(), marker='x', s=40, color=palette[4], label="Noise data")
# plt.scatter(t[peaks], y[peaks], color='r', label='Peaks')
# plt.scatter(t[troughs], y[troughs], color='g', label='Troughs')
plt.xlabel("Time")
plt.ylabel("y")
plt.legend(loc='upper left', fontsize='small')
plt.show()


import deepxde as dde
import numpy as np
import matplotlib.pyplot as plt
import time

def ode(t, y, k1=15, k2=5):
    dy_tt = dde.grad.hessian(y, t)
    dy_t = dde.grad.jacobian(y, t)
    return dy_tt - k1 * k2 * (1 - y ** 2) * dy_t + k1 * k1 * y


geom = dde.geometry.TimeDomain(0.0, 1.5)

# y (t = 0) = 1
ic1 = dde.icbc.IC(geom, lambda x : 1, lambda _, on_initial: on_initial)


def boundary_l(t, on_boundary):
    return on_boundary and dde.utils.isclose(t[0], 0)


def error_derivative(inputs, outputs, X):
    return dde.grad.jacobian(outputs, inputs, i=0, j=None)


ic2 = dde.icbc.OperatorBC(geom, error_derivative, boundary_l)

t_y_data = dde.PointSetBC(t_data, y_data)
t_y_data_noise = dde.PointSetBC(t_data, y_data_noise)

data = dde.data.TimePDE(geom, ode, [ic1, ic2, t_y_data, ], train_distribution = "uniform", num_domain=48, num_boundary=1,
)

net = dde.maps.FNN([1] + [32] * 3 + [1], "tanh", "Glorot normal")

model = dde.Model(data, net)
model.compile("adam", lr=3e-4)

start_time = time.time()

model.train(epochs=24000)

end_time = time.time()
total_time = end_time - start_time
print(f"Total training time: {total_time:.2f} seconds")

y_pred = model.predict(t)


num_domain = np.linspace(0, 1.5, 48) # 15

plt.figure(figsize=(7, 4))
plt.plot(t, y, '-', color=palette[0], linewidth=2, label='Excat solution')
plt.plot(t, y_pred, '--', color=palette[1], linewidth=2, label='PINN prediction')
plt.plot(t_data, y_data, 'o', color=palette[2], linewidth=2, alpha=0.7, label='Training data')
plt.plot(num_domain, np.zeros_like(num_domain), '.', color=palette[3], linewidth=2, alpha=0.7, label='Coloc. points')
# plt.scatter(t_data, y_data_noise.ravel(), marker='x', s=40, color=palette[4], label="Noise data")
plt.title(r'VDP Oscillator ($\epsilon=1$)', fontsize=15, fontweight='medium')
plt.xlabel('Time', fontsize=12)
plt.ylabel('y', fontsize=12)
plt.legend(frameon=True, loc='upper right', fontsize=9)
plt.xlim([-0.1, 2.15])
plt.show()

